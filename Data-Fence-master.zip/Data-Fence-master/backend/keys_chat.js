module.exports = {
  mongoURI: 'mongodb://admin:admin123@ds237955.mlab.com:37955/umslhack',
  secretOrKey: 'SECRET'
};
